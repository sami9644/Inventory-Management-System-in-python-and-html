from flask import *
import requests
import db
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import uuid,os

app = Flask(__name__)
CORS(app, origins=["*"])

def item_price(itemid):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT price FROM items WHERE id = ?",(itemid,))
        data = cur.fetchone()[0]
    return data

def isAvailable(itemid):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM orders WHERE item = ?",(itemid,))
        data = cur.fetchall()
    return bool(data)

def name_model(itemid):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT itemname,pcs,model,price FROM items WHERE id = ?",(itemid,))
        data = cur.fetchone()
    return data

def reduce_pcs(itemid, pccs):
    with db.database() as conn:
        cur = conn.cursor()
        # Fetch current bulk amount and total pieces
        cur.execute("SELECT amount, pcs FROM items WHERE id = ?", (itemid,))
        data = cur.fetchone()
        
        current_bulk_amount = float(data[0])
        current_total_pcs = int(data[1])
        
        # 1. Calculate the ratio (e.g., 12 pieces per dozen or 100 kg per bag)
        # We find this by dividing total pieces by the bulk amount
        pcs_per_unit = current_total_pcs / current_bulk_amount
        
        # 2. Subtract the purchased pieces
        remaining_pcs = current_total_pcs - pccs
        
        # 3. Calculate the new bulk amount using the ratio
        reduced_bulk = remaining_pcs / pcs_per_unit
        
        # 4. Update the database
        cur.execute("UPDATE items SET amount = ?, pcs = ? WHERE id = ?", 
                    (reduced_bulk, remaining_pcs, itemid))
        conn.commit()


def check_pcs(itemid,des):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT pcs FROM items WHERE id = ?",(itemid,))
        data = cur.fetchone()
        pcs = int(data[0])
        if pcs != 0 and (des<pcs):
            return True
        else:
            return False





@app.route("/")
def test():
    with db.database() as conn:
        cur = conn.cursor()
        # cur.execute("DELETE FROM orders")
        cur.execute("SELECT * FROM orders")
        data = cur.fetchall()
    return data



@app.route("/register/employee/", methods=['POST'])
def register_employee(): # Removed 'tel' arg since it comes from JSON body
    req_data = request.get_json()
    tel = req_data.get('phoneno')
    password = req_data.get('password')
    
    with db.database() as conn:
        cur = conn.cursor()
        # Check if employee exists
        cur.execute("SELECT * FROM employees WHERE phoneno = ? AND password IS NULL", (tel,))
        data = cur.fetchone()
        
        if data:
            hashed = generate_password_hash(password)
            # Update the existing record with the new password
            cur.execute("UPDATE employees SET password = ? WHERE phoneno = ?", (hashed, tel))
            conn.commit()
            return {'status': 'success', 'message': 'Account activated!'}
        else:
            return {'status': 'error', 'message': 'Phone number not recognized.'}, 404

# get bulk amount 
@app.route("/get/bulk/<itemid>")
def getbulk(itemid):
    bulk = fetch_bulk(itemid)
    return {"bulk":bulk}


# log in for employee


@app.route("/login", methods=["POST"])
def login():
    req_data = request.get_json()
    tel = req_data.get('phoneno')
    password = req_data.get('password')
    
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM employees WHERE phoneno = ?", (tel,))
        data = cur.fetchone()
        
        # data[4]: hashed_password, data[3]: role, data[1]: fullname
        if data and check_password_hash(data[4], password):
            # No session saving here—just send the data back to JS
            return jsonify({
                'status': 'success',
                'role': data[3].lower().replace(" ", ""), # 'storemanager'
                'name': data[1]
            })
        else:
            return jsonify({
                'status': 'error', 
                'message': 'Invalid phone or password'
            }), 401





# api requests for storemanager

@app.route("/api/add-item", methods=['POST'])
def add_item():
    req = request.get_json()
    
    # Extract data from the JSON request
    # Note: data['id'] and data['addedon'] are generated in the JS above
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO items (id, itemname, model, price, amount, pcs, shelfrow, addedon)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            req.get('id'),
            req.get('itemname'),
            req.get('model'),
            float(req.get('price')),
            float(req.get('amount')),
            int(req.get('pcs')),
            int(req.get('shelfrow')),
            req.get('addedon')
        ))
        conn.commit()
    
    return {"status": "success"}, 201


# List all items
@app.route("/api/get-items", methods=['GET'])
def get_items():
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id, itemname, model, pcs, shelfrow FROM items")
        rows = cur.fetchall()
        
        items = []
        for row in rows:
            items.append({
                "id": row[0],
                "itemname": row[1],
                "model": row[2],
                "pcs": row[3],
                "shelfrow": row[4]
            })
    return {"items": items}

# Delete an item
@app.route("/api/delete-item/<id>", methods=['DELETE'])
def delete_item(id):
    if not isAvailable(id):
        with db.database() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM items WHERE id = ?", (id,))
            conn.commit()
        return {"status": "success","message":f"succesfully deleted itemid :{id}"}
    else:
        return {'status':'error','message':'This item is ordered by customer cant be deleted!'}



# Fetch single item for the Edit Page
@app.route("/api/get-item/<id>", methods=['GET'])
def get_single_item(id):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id, itemname, model, price, pcs FROM items WHERE id = ?", (id,))
        row = cur.fetchone()
        if row:
            item = {"id": row[0], "itemname": row[1], "model": row[2], "price": row[3], "pcs": row[4]}
            return {"status": "success", "item": item}
    return {"status": "error"}, 404

# Update item details
@app.route("/api/update-item", methods=['PUT'])
def update_item():
    req = request.get_json()
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("""
            UPDATE items 
            SET itemname = ?, model = ?, price = ?, pcs = ? 
            WHERE id = ?
        """, (req.get('itemname'), req.get('model'), req.get('price'), req.get('pcs'), req.get('id')))
        conn.commit()
    return {"status": "success"}



#stock alert
@app.route("/api/stock-alerts", methods=['GET'])
def get_stock_alerts():
    threshold = 10  # You can change this number based on your needs
    with db.database() as conn:
        cur = conn.cursor()
        # Find items where pcs is less than the threshold
        cur.execute("""
            SELECT id, itemname, model, pcs, shelfrow 
            FROM items 
            WHERE pcs <= ? 
            ORDER BY pcs ASC
        """, (threshold,))
        rows = cur.fetchall()
        
        alerts = []
        for row in rows:
            alerts.append({
                "id": row[0],
                "itemname": row[1],
                "model": row[2],
                "pcs": row[3],
                "shelfrow": row[4]
            })
            
    return {
        "status": "success",
        "alerts": alerts,
        "count": len(alerts),
        "threshold": threshold
    }

@app.route("/api/sales-report")
def sales_report():
    salesarr = []
    grand_total = 0
    
    with db.database() as conn:
        cur = conn.cursor()
        # Ensure your column name for 'paid' status is correct (ispaid vs order_status)
        cur.execute("SELECT * FROM orders WHERE ispaid = ?", ('paid',))
        datas = cur.fetchall()
        
        for data in datas:
            subtotal = float(data[6]) # Ensure price/paidamt is a number
            grand_total += subtotal
            
            salesarr.append({
                "name": name_model(data[7])[0], # Extract name from your function
                "qty": data[2],
                "customer": data[3], # Added customer for the .substring(0,8) call
                "subtotal": subtotal
            })
            
    # Return keys that the JS is actually looking for
    return {
        "status": "success", 
        "sales": salesarr, 
        "grand_total": grand_total, 
        "total_count": len(salesarr)
    }
# end of store manager






# api requests for picker

@app.route("/api/pending/orders")
def pending_orders():
    pending = []
    with db.database() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM orders WHERE ispaid = ?",('pending',))
        datas = cursor.fetchall()

        for data in datas:
            pending.append({
                "orderid":data[0],
                "total_item":data[2],
                "buyer":data[3],
                "tin_no":data[4],
                "vat":'with vat' if data[5] == 'yes' else 'without vat',
                "price":data[6],
                "item":name_model(data[7])[0],
                "availablity": True if name_model(data[7])[1] else False,
                "itemid":data[7]
                })
    return {"status":"success","orders":pending}


@app.route("/api/ready/order/<orderid>")
def makeit_ready(orderid):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE orders SET ispaid = ? WHERE orderid = ?",('paid',orderid,))
        conn.commit()
    return {"message":"Order is now ready and sent to the cashier"}

# end of store picker



# api requests for cashier

@app.route("/api/paid/orders")
def paid_orders():
    pending = []
    with db.database() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM orders WHERE ispaid = ?",('paid',))
        datas = cursor.fetchall()

        for data in datas:
            pending.append({
                "orderid":data[0],
                "total_item":data[2],
                "buyer":data[3],
                "tin_no":data[4],
                "vat":'with vat' if data[5] == 'yes' else 'without vat',
                "price":data[6],
                "item":name_model(data[7])[0],
                "availablity": True if name_model(data[7])[1] else False,
                "itemid":data[7],
                'totalamt':name_model(data[7])[1]
                })
    return {"status":"success","orders":pending}


@app.route("/api/invoice/<tin>")
def invoice(tin):
    ordersList=[]
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM orders WHERE tin_no = ?",(tin,))
        orders = cur.fetchall()
        for order in orders:
            ordersList.append({
                "company_name":order[3],
                "itemname":f"{name_model(order[7])[0]} {name_model(order[7])[2]}",
                "total_item":order[2],
                "itemprice":name_model(order[7])[3],
                "total_paid":order[6
                ]
                })
    return {"status":"success","orders":ordersList}


# end of store cashier




# api requests for sales




@app.route("/api/customer/items", methods=['GET'])
def get_customer_items():
    with db.database() as conn:
        cur = conn.cursor()
        # Only show items that have at least 1 piece in stock
        query = "SELECT id, itemname, model, price, pcs, shelfrow,amount FROM items WHERE pcs > 0"
        cur.execute(query)
        rows = cur.fetchall()
        
        items = []
        for row in rows:
            items.append({
                "id": row[0],
                "itemname": row[1],
                "model": row[2],
                "price": row[3],
                "pcs": row[4],
                "shelf": row[5],
                "amt":row[6]
            })
            
    return {"status": "success", "items": items}



@app.route('/api/staff/view-orders', methods=['GET'])
def get_orders():
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM orders")
        # Map rows to dictionaries for JSON response
        columns = [col[0] for col in cur.description]
        rows = [dict(zip(columns, row)) for row in cur.fetchall()]
    return jsonify(rows)


@app.route('/api/staff/create-order', methods=['POST'])
def create_order():
    data = request.get_json()
    orderid = str(uuid.uuid4())
    ispaid = data.get("ispaid")
    total_item = data.get("total_item")
    company_name = data.get("company_name")
    tin_no = data.get("tin_no")
    with_vat_or_no = data.get("with_vat_or_no")
    item = data.get("item")
    # total_price = data.get("total_price")
    reduce_pcs(item,total_item)
    if check_pcs(item,total_item):
        if with_vat_or_no == 'yes':
            vat_price = float(total_item)* float(item_price(item)*0.15)
            price = float(total_item)* float(item_price(item))
            total_price = vat_price+price
            with db.database() as conn:
                cur = conn.cursor()
                cur.execute("INSERT INTO orders(orderid,ispaid,total_item,company_name,tin_no,with_vat_or_no,item,total_price,order_status) VALUES (?,?,?,?,?,?,?,?,?)",(orderid,ispaid,total_item,company_name,tin_no,with_vat_or_no,item,total_price,'pending'))
                conn.commit()
                return {'status':'success','message':'successfully done'}
        else:
            total_price= float(total_item)* float(item_price(item))
            with db.database() as conn:
                cur = conn.cursor()
                cur.execute("INSERT INTO orders(orderid,ispaid,total_item,company_name,tin_no,with_vat_or_no,item,total_price) VALUES (?,?,?,?,?,?,?,?)",(orderid,ispaid,total_item,company_name,tin_no,with_vat_or_no,item,total_price))
                conn.commit()
                return {'status':'success','message':'successfully done'}
    else:
        return {'status':"error","message":"Invalid number of pieces"}




# end

if __name__ == '__main__':
	app.run(debug=True,port=3000,host="0.0.0.0")