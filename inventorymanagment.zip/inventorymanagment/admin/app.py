from flask import *
import db
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = "DHAISUdhueiwhrf78w87348tudghsiugf"


def name_model(itemid):
    with db.database() as conn:
        cur = conn.cursor()
        cur.execute("SELECT itemname,pcs,model FROM items WHERE id = ?",(itemid,))
        data = cur.fetchone()
    return data

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if 'user_id' is in the session
        if 'admin' not in session:
            flash("Please log in to access the warehouse system.", "warning")
            return redirect(url_for('home')) # Redirect to your login route
        return f(*args, **kwargs)
    return decorated_function

@app.route("/",methods=['GET','POST'])
def home():
	if request.method == "GET":
		return render_template("home.html")
	elif request.method == "POST":
		login = db.login(request.form['adminUser'],request.form['adminPass'])
		if login:
			session['admin'] = login[0]
			return redirect('/admin/dashboard')
		else:
			return '<script>alert("Wrong credentials");window.location.href="/"</script>'

@app.route("/admin/dashboard")
@login_required
def dashboard():
	return render_template("dashboard.html")

@app.route("/register/employees",methods=['GET','POST'])
@login_required
def registeremp():
	if request.method == 'GET':
		return render_template("reg.html")
	elif request.method == "POST":
		employee_id = request.form.get('id')
		phone = request.form.get('phone')
		role = request.form.get("role")
		fullname = request.form.get("fullname")
		reg = db.registeremp(employee_id,fullname,phone,role)
		if reg:
			return '<script>alert("Successfully registered");window.location.href="/admin/dashboard"</script>'
		else:
			return '<script>alert("This employee has already been registered");window.location.href="/admin/dashboard"</script>',500
	else:
		return 'MEthod not allowerd',405

@app.route("/manage/employees")
@login_required
def manage():
	employees = db.showemps()
	return render_template("manage.html",employees=employees)

@app.route("/delete/<empid>",methods=['POST'])
@login_required
def deleteemp(empid):
	db.deleteem(empid)
	return '<script>alert("Successfully deleted!");window.location.href="/admin/dashboard"</script>'


@app.route('/sales/report')
@login_required
def sales_report():
	with db.database() as conn:
		cur = conn.cursor()
		cur.execute("SELECT * FROM orders")
		data = cur.fetchall()
	return render_template('report.html',reports=data,iteminfo=name_model)

@app.route('/items')
@login_required
def iteminfo():
	with db.database() as conn:
		cur = conn.cursor()
		cur.execute("SELECT * FROM items")
		data = cur.fetchall()
	return render_template("stock.html",items = data)

@app.route("/logout")
def logout():
	session.clear()
	return redirect(url_for('home'))

if __name__ == '__main__':
	app.run(debug=True,host='0.0.0.0',port='4000')




