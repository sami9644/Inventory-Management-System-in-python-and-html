import sqlite3
import uuid

def database():
    # Using a context manager here is good practice
    return sqlite3.connect('invv.db')
 
def createdb(): 
    try:
        with database() as conn:
            cur = conn.cursor()
            cur.executescript("""
            CREATE TABLE IF NOT EXISTS customers (
                id VARCHAR(200) PRIMARY KEY,
                fullname TEXT,
                phoneno VARCHAR(40) UNIQUE,
                companyname TEXT,
                TIN VARCHAR(150) UNIQUE,
                isverified VARCHAR(25) DEFAULT 'No',
                password VARCHAR(50)
            );

            CREATE TABLE IF NOT EXISTS employees(
                id VARCHAR(200) PRIMARY KEY,
                fullname TEXT,
                phoneno VARCHAR(40) UNIQUE,
                role VARCHAR(100),
                password VARCHAR(50)
            );

            CREATE TABLE IF NOT EXISTS items (
                id VARCHAR(200) PRIMARY KEY,
                itemname TEXT,
                model TEXT,
                price FLOAT,
                amount FLOAT,
                pcs INT,
                shelfrow INT,
                addedon TEXT
            );

            CREATE TABLE IF NOT EXISTS credits (
                id VARCHAR(200) PRIMARY KEY,
                customer VARCHAR(200),
                payment FLOAT,
                deadline TEXT,
                FOREIGN KEY(customer) REFERENCES customers(id)
            );


            CREATE TABLE IF NOT EXISTS admins(
                admin TEXT,
                password VARCHAR(200)
            );

            CREATE TABLE IF NOT EXISTS orders(
                orderid VARCHAR(200) PRIMARY KEY,
                ispaid VARCHAR(50) DEFAULT "pending",
                total_item FLOAT,
                company_name VARCHAR(200),
                tin_no VARCHAR(30),
                with_vat_or_no VARCHAR(30),
                total_price FLOAT,
                item VARCHAR(200),
                FOREIGN KEY(item) REFERENCES items(id)
            );

            ALTER TABLE orders ADD COLUMN order_status VARCHAR(100);

            -- Use 'INSERT OR IGNORE' so it doesn't crash if you run this twice
            INSERT OR IGNORE INTO admins (admin, password) VALUES ('admin', '1234');

            """)
            
            # Commit is handled automatically by 'with database() as conn' 
            # if no exception occurs, but adding it explicitly is fine.
            print("Database and tables created successfully!")
            
    except sqlite3.Error as e:
        print(f"Database error: {e}")


def login (admin,password):
	with database() as conn:
		cur = conn.cursor()
		cur.execute("SELECT * FROM admins WHERE admin = ? AND password = ?",(admin,password,))
		data = cur.fetchone()
	if data:
		return data
	else:
		return False


def registeremp(idno,fullname,phoneno,role):
	try:
		with database() as conn:
			cur =conn.cursor()
			cur.execute("INSERT INTO employees(id,fullname,phoneno,role) VALUES(?,?,?,?)",(idno,fullname,phoneno,role))
			conn.commit()
		return True

	except Exception as e:
		print(e)
		return False



def showemps():
	try:
		with database() as conn:
			cur =conn.cursor()
			cur.execute("SELECT * FROM employees")
			data = cur.fetchall()
		return data
	except Exception as e:
		print(e)
		return False

def deleteem(idno):
	try:
		with database() as conn:
			cur =conn.cursor()
			cur.execute("DELETE FROM employees WHERE id = ?",(idno,))
			conn.commit()
		return True
	except Exception as e:
		print(e)
		return False







# createdb()










