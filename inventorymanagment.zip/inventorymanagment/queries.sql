CREATE DATABASE inventorydb;

CREATE TABLE users (
id VARCHAR(200) PRIMARY KEY,
fullname TEXT,
phoneno VARCHAR(40) UNIQUE, 
companyname TEXT,
TIN VARCHAR(150) UNIQUE,
password VARCHAR(50)
);

CREATE TABLE storemanager(
id VARCHAR(200) PRIMARY KEY,
fullname TEXT,
phoneno VARCHAR(40) UNIQUE, 
password VARCHAR(50)
);

CREATE TABLE items (
id VARCHAR(200) PRIMARY KEY,
itemname TEXT,
model TEXT,
price FLOAT,
amount INT,
shelfrow INT,
addedon TEXT
);

CREATE TABLE credits (
customer VARCHAR(200),
payment FLOAT,
FOREIGN KEY(customer) REFERENCES users(id)
);

CREATE TABLE admins(
admin TEXT,
password VARCHAR(200),
);

INSERT INTO admins VALUES ('admin','1234')