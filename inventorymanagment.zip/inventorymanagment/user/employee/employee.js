document.addEventListener('DOMContentLoaded', function() {
    // Select the form element specifically
    const activationForm = document.querySelector('#activate form');
    const activateBtn = activationForm.querySelector('.btn-employee');

    activationForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Stop the default page reload

        // 1. Initialize FormData from the form element
        const formData = new FormData(activationForm);
        
        // 2. Convert FormData to a standard Object for JSON transmission
        const data = Object.fromEntries(formData.entries());

        // Basic Validation
        if (!data.phoneno || !data.password) {
            alert("Please fill in all fields.");
            return;
        }

        // UI State: Loading
        activateBtn.innerText = "Processing...";
        activateBtn.disabled = true;

        try {
            const response = await fetch('http://127.0.0.1:3000/register/employee/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data) // Send the converted object
            });

            const result = await response.json();

            if (response.ok) {
                alert("Account Activated! You can now login.");
                const loginTab = new bootstrap.Tab(document.querySelector('#login-tab'));
                loginTab.show();
                activationForm.reset(); // Clear the form
            } else {
                alert(result.message || "Activation failed.");
            }
        } catch (error) {
            console.error("Fetch Error:", error);
            alert("Server connection failed.");
        } finally {
            activateBtn.innerText = "Activate Account";
            activateBtn.disabled = false;
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('#login form');
    const loginBtn = loginForm.querySelector('.btn-employee');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(loginForm);
        const data = Object.fromEntries(formData.entries());

        loginBtn.innerText = "Authenticating...";
        loginBtn.disabled = true;

        try {
            const response = await fetch('http://127.0.0.1:3000/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok && result.status === 'success') {
                // 1. Store the data in JS sessionStorage
                sessionStorage.setItem('employee_name', result.name);
                sessionStorage.setItem('employee_role', result.role);
                sessionStorage.setItem('isLoggedIn', 'true');

                // 2. Dynamic Redirect
                // This looks for a file like 'cashier.html' or 'sales.html'
                window.location.href = `${result.role}.html`;
            } else {
                alert(result.message);
                loginBtn.disabled = false;
                loginBtn.innerText = "Enter Workspace";
            }
        } catch (error) {
            console.error("Connection Error:", error);
            alert("Could not reach the server.");
            loginBtn.disabled = false;
        }
    });
});